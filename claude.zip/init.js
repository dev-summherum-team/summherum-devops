// ================================================================
// db/init.js – wird beim ersten Container-Start automatisch ausgeführt
// Legt Collections an und füllt sie mit Beispieldaten
// ================================================================

// Wechsle zur App-Datenbank
db = db.getSiblingDB('reisetagebuch');

// ----------------------------------------------------------------
// Collection: reisen
// Jede Reise gehört einem Benutzer
// ----------------------------------------------------------------
db.createCollection('reisen');
db.reisen.insertMany([
  {
    benutzername: "heike",
    titel: "Sommerurlaub Portugal",
    reiseziel: "Lissabon, Portugal",
    startDatum: new Date("2025-07-01"),
    endDatum: new Date("2025-07-14"),
    erstellt: new Date()
  }
]);

// ----------------------------------------------------------------
// Collection: eintraege
// Tagebucheinträge mit optionalen Feldern (flexibel!)
// ----------------------------------------------------------------
db.createCollection('eintraege');
db.eintraege.insertMany([
  {
    benutzername: "heike",
    reiseTitel: "Sommerurlaub Portugal",
    datum: new Date("2025-07-01"),
    titel: "Ankunft in Lissabon",
    beschreibung: "Endlich da! Die Stadt ist wunderschön.",
    ort: "Lissabon",
    koordinaten: { lat: 38.7169, lng: -9.1399 },
    // Wetter ist optional – muss nicht immer da sein
    wetter: {
      temperatur: 28,
      beschreibung: "Sonnig",
      einheit: "°C"
    },
    erstellt: new Date()
  },
  {
    benutzername: "heike",
    reiseTitel: "Sommerurlaub Portugal",
    datum: new Date("2025-07-03"),
    titel: "Sintra-Ausflug",
    beschreibung: "Der Palácio da Pena war beeindruckend!",
    ort: "Sintra",
    koordinaten: { lat: 38.7879, lng: -9.3906 },
    erstellt: new Date()
  }
]);

// ----------------------------------------------------------------
// Collection: packlisten
// Vorlagen + eigene Listen
// ----------------------------------------------------------------
db.createCollection('packlisten');
db.packlisten.insertMany([
  {
    name: "Sommer-Vorlage",
    istVorlage: true,
    jahreszeit: "sommer",
    items: [
      { name: "Sonnencreme LSF 50", erledigt: false },
      { name: "Sonnenbrille", erledigt: false },
      { name: "Leichte T-Shirts (5x)", erledigt: false },
      { name: "Shorts (3x)", erledigt: false },
      { name: "Badeanzug/Badehose", erledigt: false },
      { name: "Flip-Flops", erledigt: false },
      { name: "Reiseadapter", erledigt: false },
      { name: "Powerbank", erledigt: false }
    ]
  },
  {
    name: "Winter-Vorlage",
    istVorlage: true,
    jahreszeit: "winter",
    items: [
      { name: "Warme Jacke", erledigt: false },
      { name: "Thermounterwäsche", erledigt: false },
      { name: "Schal + Mütze + Handschuhe", erledigt: false },
      { name: "Warme Socken (5x)", erledigt: false },
      { name: "Stiefel", erledigt: false },
      { name: "Lippenpflegestift", erledigt: false }
    ]
  },
  {
    name: "Immer dabei",
    istVorlage: true,
    jahreszeit: "alle",
    items: [
      { name: "Reisepass / Personalausweis", erledigt: false },
      { name: "Krankenversicherungskarte", erledigt: false },
      { name: "Ladekabel Handy", erledigt: false },
      { name: "Zahnbürste + Zahnpasta", erledigt: false },
      { name: "Kopfhörer", erledigt: false }
    ]
  }
]);

// ----------------------------------------------------------------
// Collection: benutzer (einfach, kein großes Auth-System)
// ----------------------------------------------------------------
db.createCollection('benutzer');
db.benutzer.insertOne({
  benutzername: "heike",
  anzeigename: "Heike",
  erstellt: new Date()
});

print("✅ Reisetagebuch-Datenbank initialisiert!");
