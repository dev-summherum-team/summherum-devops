# 🧳 Reisetagebuch – DevOps Projekt

Digitales Reisetagebuch als Web-App | Java 21 · Javalin · MongoDB · Docker

---

## 🗺️ Tech-Stack (und warum)

| Was | Womit | Warum |
|-----|-------|-------|
| Sprache | Java 21 | Vorgabe Modul, kein Spring Boot |
| Web-Framework | Javalin | Leichtgewichtig, einfach, kein Framework-Overhead |
| Datenbank | MongoDB | Flexibel für unterschiedliche Eintragstypen |
| Container | Docker + Compose | Gleiche Umgebung für alle Teammitglieder |
| Karte | Leaflet.js | Kostenlos, Open Source, einfach einzubinden |
| Wetter-API | Open-Meteo | Kostenlos, kein API-Key nötig |

---

## 🚀 Schnellstart (jedes Teammitglied macht das einmal)

```bash
# 1. Repository klonen
git clone https://github.com/EUER-REPO/reisetagebuch.git
cd reisetagebuch

# 2. Umgebungsvariablen einrichten (einmalig)
cp .env.example .env

# 3. Alles bauen und starten
docker compose up --build
```

**Fertig!** App läuft auf → http://localhost:8080

---

## 📁 Projektstruktur

```
reisetagebuch/
├── src/
│   └── main/
│       ├── java/com/reisetagebuch/
│       │   ├── Main.java              ← Startpunkt der App
│       │   ├── config/
│       │   │   └── MongoConfig.java   ← DB-Verbindung
│       │   ├── routes/
│       │   │   ├── EintragRoutes.java ← API-Endpunkte für Einträge
│       │   │   ├── ReiseRoutes.java   ← API-Endpunkte für Reisen
│       │   │   └── PacklisteRoutes.java
│       │   ├── service/
│       │   │   ├── EintragService.java ← Business-Logik
│       │   │   ├── ReiseService.java
│       │   │   └── WetterService.java  ← Open-Meteo API
│       │   └── model/
│       │       ├── Eintrag.java        ← Datenmodelle
│       │       └── Reise.java
│       └── resources/
│           ├── public/                 ← HTML, CSS, JS (Frontend)
│           │   ├── index.html
│           │   ├── style.css
│           │   └── app.js
│           └── logback.xml            ← Logging-Konfiguration
├── db/
│   └── init.js                        ← MongoDB Startdaten
├── Dockerfile
├── docker-compose.yml
├── pom.xml
├── .env.example                       ← Vorlage (ins Git)
├── .env                               ← Deine Werte (NICHT ins Git!)
└── .gitignore
```

---

## 🛠️ Wichtige Befehle

```bash
# Neu bauen (nach Code-Änderungen)
docker compose up --build

# Im Hintergrund laufen lassen
docker compose up -d

# Logs der App anschauen
docker compose logs -f app

# Logs der Datenbank anschauen
docker compose logs -f db

# Alles stoppen
docker compose down

# Stoppen + alle Daten löschen (DB zurücksetzen)
docker compose down -v
```

---

## 🗄️ Datenbank direkt ansprechen

```bash
# In MongoDB-Shell wechseln
docker exec -it reisetagebuch-db mongosh -u reise_user -p reise_pass_123 reisetagebuch

# Collections anzeigen
show collections

# Einträge anzeigen
db.eintraege.find().pretty()
```

Oder mit **MongoDB Compass** (GUI):
- URI: `mongodb://reise_user:reise_pass_123@localhost:27017/reisetagebuch?authSource=admin`

---

## 🌐 API-Endpunkte (geplant)

| Methode | Pfad | Was |
|---------|------|-----|
| GET | `/` | Startseite |
| GET | `/health` | Health-Check für Docker |
| GET | `/api/reisen` | Alle Reisen laden |
| POST | `/api/reisen` | Neue Reise anlegen |
| GET | `/api/eintraege` | Alle Einträge (Timeline) |
| POST | `/api/eintraege` | Neuen Eintrag schreiben |
| GET | `/api/packlisten/vorlagen` | Packlisten-Vorlagen |
| GET | `/api/wetter?lat=...&lng=...` | Wetterdaten holen |
| GET | `/api/zufall` | Zufalls-Reiseziel |

---

## 👥 Team-Workflow

```bash
# Neues Feature starten
git checkout -b feature/mein-feature

# Änderungen commiten
git add .
git commit -m "feat: Neue Funktion XY"

# Pushen und Pull Request erstellen
git push origin feature/mein-feature
```

**Goldene Regel:** Die `.env` Datei kommt NIEMALS ins Git!
